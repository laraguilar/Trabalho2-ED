#include <opencv2/opencv.hpp>

int main()
{
    // Carregar as imagens
    cv::Mat imagem1 = cv::imread("foto.jpeg");
    cv::Mat imagem2 = cv::imread("foto2.jpeg");

    // Converter as imagens para escala de cinza
    cv::Mat imagem1_cinza, imagem2_cinza;
    cv::cvtColor(imagem1, imagem1_cinza, cv::COLOR_BGR2GRAY);
    cv::cvtColor(imagem2, imagem2_cinza, cv::COLOR_BGR2GRAY);

    // Criar o objeto SIFT e detectar os pontos de interesse e descritores para as duas imagens
    cv::Ptr<cv::SIFT> sift = cv::SIFT::create();
    std::vector<cv::KeyPoint> keypoints1, keypoints2;
    cv::Mat descritores1, descritores2;
    sift->detectAndCompute(imagem1_cinza, cv::noArray(), keypoints1, descritores1);
    sift->detectAndCompute(imagem2_cinza, cv::noArray(), keypoints2, descritores2);

    // Usar um algoritmo de correspondência para encontrar as correspondências entre os descritores das duas imagens
    cv::BFMatcher matcher;
    std::vector<std::vector<cv::DMatch>> correspondencias;
    matcher.knnMatch(descritores1, descritores2, correspondencias, 2);

    // Aplicar um critério de filtragem nas correspondências para obter aquelas mais robustas
    std::vector<cv::DMatch> correspondencias_boas;
    for (size_t i = 0; i < correspondencias.size(); i++)
    {
        if (correspondencias[i][0].distance < 0.75 * correspondencias[i][1].distance)
        {
            correspondencias_boas.push_back(correspondencias[i][0]);
        }
    }

    // Desenhar as correspondências encontradas nas imagens
    cv::Mat imagem_com_correspondencias;
    cv::drawMatches(imagem1, keypoints1, imagem2, keypoints2, correspondencias_boas, imagem_com_correspondencias);

    // Mostrar a imagem com as correspondências
    cv::imshow("Correspondencias", imagem_com_correspondencias);
    cv::waitKey(0);
    cv::destroyAllWindows();

    // Avaliar a similaridade entre as imagens
    int numero_correspondencias = correspondencias_boas.size();
    std::cout << "Numero de correspondencias: " << numero_correspondencias << std::endl;

    return 0;
}
