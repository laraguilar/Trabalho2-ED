import sys
import numpy as np
import cv2 as cv
import matplotlib.pyplot as plt

sift = cv.SIFT_create()

bf = cv.BFMatcher(cv.NORM_L2, crossCheck=True)

img_name = sys.argv[1]

descriptor_filename = sys.argv[2]

img = cv.imread(img_name)
img= cv.cvtColor(img, cv.COLOR_BGR2GRAY)

keypoints_1, descriptors_1 = sift.detectAndCompute(img, None)

# print(descriptor_filename)

with open(descriptor_filename, "w") as fp:
    fp.write("teste")

for i in descriptors_1:
    for j in i:
        print(j)
