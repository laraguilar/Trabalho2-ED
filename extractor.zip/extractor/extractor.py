import numpy as np
import cv2

imagem1 = cv2.imread('foto.jpeg')
imagem2 = cv2.imread('foto6.jpeg')

imagem1_cinza = cv2.cvtColor(imagem1, cv2.COLOR_BGR2GRAY)
imagem2_cinza = cv2.cvtColor(imagem2, cv2.COLOR_BGR2GRAY)

sift = cv2.SIFT_create()

# Detectar pontos de interesse e descritores para a imagem 1
pontos_chave1, descritores1 = sift.detectAndCompute(imagem1_cinza, None)

# Detectar pontos de interesse e descritores para a imagem 2
pontos_chave2, descritores2 = sift.detectAndCompute(imagem2_cinza, None)


bf = cv2.BFMatcher()
correspondencias = bf.knnMatch(descritores1, descritores2, k=2)


correspondencias_boas = []
for m, n in correspondencias:
    if m.distance < 0.75 * n.distance:
        correspondencias_boas.append(m)
        # print("M: {%.2f} N: {%.2f}", m.distance, n.distance)

imagem_com_correspondencias = cv2.drawMatches(imagem1, pontos_chave1, imagem2, pontos_chave2, correspondencias_boas, None, flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)
# cv2.imshow("Correspondências", imagem_com_correspondencias)
# cv2.waitKey(0)
# cv2.destroyAllWindows()


cv2.imwrite("boas.jpeg", imagem_com_correspondencias)

# print(correspondencias)
numero_correspondencias = len(correspondencias_boas)
print("Número de correspondências:", numero_correspondencias)
