import sys
import numpy as np
import cv2 as cv
import matplotlib.pyplot as plt

sift = cv.SIFT_create()

bf = cv.BFMatcher(cv.NORM_L2, crossCheck=True)

img1_name = sys.argv[1]
# img2_name = sys.argv[2]

img1 = cv.imread(img1_name)
# img2 = cv.imread(img2_name)

img1= cv.cvtColor(img1, cv.COLOR_BGR2GRAY)
# img2= cv.cvtColor(img2, cv.COLOR_BGR2GRAY)

keypoints_1, descriptors_1 = sift.detectAndCompute(img1, None)
# keypoints_2, descriptors_2 = sift.detectAndCompute(img2, None)

print(descriptors_1)

# matches = bf.match(descriptors_1, descriptors_2)
# matches = sorted(matches, key = lambda x:x.distance)
# # print(len(matches))

# img_match = cv.drawMatches(img1, keypoints_1, img2, keypoints_2, matches[300:600], img2, flags=2)

# # cv.imshow('SIFT', img_match)
# # cv.waitKey(0)

# # cv.imwrite('match.jpeg', img_match)

# plt.imshow(img_match),plt.show()

